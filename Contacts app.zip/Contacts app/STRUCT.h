#ifndef STRUCT_H_
#define STRUCT_H_
#include <iostream>
using namespace std;

struct node
{
	node *next;
	unsigned int phone_no;
	string name;
};
#endif
